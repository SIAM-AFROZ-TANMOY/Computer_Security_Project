
PHISHSHIELD AI - FINAL PROJECT BACKUP
=====================================

Backup created: 2026-10-02 11:00:31

Project:
PhishShield AI - Multimodal Phishing Detection System

Main detection branches:
1. URL CNN
2. URL BiLSTM
3. Screenshot CNN
4. HTML Neural Network

Current working fusion:
URL + Visual
URL weight   = 60%
Visual weight = 40%
Threshold    = 0.30

Backend:
FastAPI
Endpoints:
GET  /
GET  /health
POST /predict/url
POST /predict/multimodal

Frontend:
Gradio

IMPORTANT:
No model retraining is required.
Keep the Colab notebook and this backup folder.
